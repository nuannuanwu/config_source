#!/bin/bash
set -ex
counter=0
if [ "${counter}" = "0" ]; then
    service keepalived stop
fi
