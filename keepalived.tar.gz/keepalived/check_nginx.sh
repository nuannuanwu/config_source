#!/bin/bash
set -ex
counter=$(ps -C nginx --no-heading|wc -l)
if [ "${counter}" = "0" ]; then
    /usr/local/nginx/sbin/nginx
    sleep 2
    counter2=$(ps -C nginx --no-heading|wc -l)
    if [ "${counter2}" = "0" ]; then
        service keepalived stop
    fi
fi
