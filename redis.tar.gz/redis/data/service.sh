#!/bin/bash
PIDFILE=/var/run/redis$2.pid
CONFIGFILE=/home/data/redis/data/redis$2.conf
do_start() {
    /home/data/redis/src/redis-server $CONFIGFILE
}
 
 do_stop() {
     kill -INT `cat $PIDFILE` || echo -n "redis port $2 not running"
 }
  
do_reload() {
    kill -HUP `cat $PIDFILE` || echo -n "redis port $2 can't reload"
}


case "$1" in
start)
echo -n "Starting redis port: $2"
do_start
echo "."
;;
stop)
echo -n "Stopping redis port: $2"
do_stop
echo "."
;;
restart)
echo -n "Restarting redis port: $2"
do_stop
do_start
echo "."
;;
*)
echo "Usage: $SCRIPTNAME {start|stop|restart}" >&2
exit 3
;;
esac
 
exit 0
